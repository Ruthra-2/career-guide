
export interface CareerRecommendation {
  title: string;
  description: string;
  reasoning: string;
  suggested_steps: string[];
}

export interface UserProfile {
  skills: string;
  grades: string;
  interests: string;
}
