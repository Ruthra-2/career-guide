
import React, { useState, useCallback } from 'react';
import { CareerRecommendation } from './types';
import { getCareerRecommendations } from './services/geminiService';
import Input from './components/Input';
import Textarea from './components/Textarea';
import Button from './components/Button';
import Loader from './components/Loader';
import CareerCard from './components/CareerCard';
import { SparklesIcon } from './components/icons/SparklesIcon';

const App: React.FC = () => {
  const [skills, setSkills] = useState<string>('');
  const [grades, setGrades] = useState<string>('');
  const [interests, setInterests] = useState<string>('');
  const [recommendations, setRecommendations] = useState<CareerRecommendation[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!skills || !grades || !interests) {
      setError('Please fill out all fields to get the best recommendations.');
      return;
    }
    setError(null);
    setIsLoading(true);
    setRecommendations([]);

    try {
      const results = await getCareerRecommendations({ skills, grades, interests });
      setRecommendations(results);
    } catch (err) {
      setError('An error occurred while fetching recommendations. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [skills, grades, interests]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200 transition-colors duration-300">
      <main className="container mx-auto px-4 py-8 md:py-12">
        <header className="text-center mb-10">
          <div className="inline-flex items-center justify-center bg-violet-100 dark:bg-violet-900/50 p-3 rounded-full mb-4">
              <SparklesIcon className="h-8 w-8 text-violet-600 dark:text-violet-400" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-white">
            AI Career Compass
          </h1>
          <p className="mt-4 text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Discover your future career path. Tell us about your skills, grades, and interests, and our AI will do the rest.
          </p>
        </header>

        <div className="max-w-2xl mx-auto bg-white dark:bg-slate-800/50 p-6 md:p-8 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700">
          <form onSubmit={handleSubmit}>
            <div className="space-y-6">
              <div>
                <label htmlFor="skills" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Your Skills
                </label>
                <Textarea
                  id="skills"
                  value={skills}
                  onChange={(e) => setSkills(e.target.value)}
                  placeholder="e.g., Python, public speaking, graphic design, problem-solving"
                  rows={3}
                />
              </div>
              <div>
                <label htmlFor="grades" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Academic Performance / Favorite Subjects
                </label>
                <Input
                  id="grades"
                  type="text"
                  value={grades}
                  onChange={(e) => setGrades(e.target.value)}
                  placeholder="e.g., 'A' in Math and Physics, enjoy History"
                />
              </div>
              <div>
                <label htmlFor="interests" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Hobbies & Interests
                </label>
                <Textarea
                  id="interests"
                  value={interests}
                  onChange={(e) => setInterests(e.target.value)}
                  placeholder="e.g., playing strategy games, building models, reading fantasy novels"
                  rows={3}
                />
              </div>
            </div>
            <div className="mt-8">
              <Button type="submit" disabled={isLoading} className="w-full">
                {isLoading ? 'Generating...' : 'Get Recommendations'}
              </Button>
            </div>
          </form>
        </div>

        {error && (
          <div className="max-w-2xl mx-auto mt-6 text-center text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-900/30 p-4 rounded-lg">
            {error}
          </div>
        )}
        
        <div className="mt-12">
          {isLoading && <Loader />}
          {recommendations.length > 0 && (
            <div className="space-y-6 max-w-4xl mx-auto">
                <h2 className="text-3xl font-bold text-center text-slate-900 dark:text-white mb-8">Your Personalized Career Paths</h2>
              {recommendations.map((rec, index) => (
                <CareerCard key={index} recommendation={rec} />
              ))}
            </div>
          )}
        </div>
      </main>
      <footer className="text-center py-6 text-sm text-slate-500 dark:text-slate-400">
        <p>Powered by Google Gemini</p>
      </footer>
    </div>
  );
};

export default App;
