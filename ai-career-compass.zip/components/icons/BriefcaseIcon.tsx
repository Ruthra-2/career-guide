
import React from 'react';

export const BriefcaseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.15v4.075c0 1.313-.964 2.414-2.18 2.58a2.585 2.585 0 01-1.82 0c-.235-.042-.455-.11-.66-.195l-3.32-1.077a.64.64 0 01-.42 0L8.84 19.81a2.625 2.625 0 01-1.82 0c-1.216-.166-2.18-1.267-2.18-2.58V14.15M3 9.375l2.021-1.347a.64.64 0 01.858 0L8.84 9.375l2.969-1.98.01.006a.64.64 0 01.858 0L15.64 9.375l2.969-1.98.01.006a.64.64 0 01.858 0L21 9.375M3 9.375V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v1.875m-18 0v.01" />
    </svg>
);
