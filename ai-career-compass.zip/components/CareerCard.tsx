
import React from 'react';
import { CareerRecommendation } from '../types';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { LightBulbIcon } from './icons/LightBulbIcon';
import { ArrowRightIcon } from './icons/ArrowRightIcon';

interface CareerCardProps {
  recommendation: CareerRecommendation;
}

const CareerCard: React.FC<CareerCardProps> = ({ recommendation }) => {
  return (
    <div className="bg-white dark:bg-slate-800/50 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 overflow-hidden transition-transform duration-300 hover:scale-[1.02] hover:shadow-xl">
      <div className="p-6 md:p-8">
        <div className="flex items-center gap-4 mb-4">
          <div className="flex-shrink-0 bg-violet-100 dark:bg-violet-900/50 p-3 rounded-full">
            <BriefcaseIcon className="h-6 w-6 text-violet-600 dark:text-violet-400" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{recommendation.title}</h3>
            <p className="text-slate-600 dark:text-slate-400">{recommendation.description}</p>
          </div>
        </div>

        <div className="mt-6 space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <LightBulbIcon className="h-5 w-5 text-amber-500" />
              <h4 className="font-semibold text-slate-800 dark:text-slate-200">Why it's a good fit:</h4>
            </div>
            <p className="text-slate-600 dark:text-slate-300 pl-7">{recommendation.reasoning}</p>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-3">
               <ArrowRightIcon className="h-5 w-5 text-green-500" />
              <h4 className="font-semibold text-slate-800 dark:text-slate-200">Your Next Steps:</h4>
            </div>
            <ul className="space-y-2 pl-7">
              {recommendation.suggested_steps.map((step, index) => (
                <li key={index} className="flex items-start">
                    <svg className="flex-shrink-0 h-5 w-5 text-violet-500 dark:text-violet-400 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  <span className="text-slate-600 dark:text-slate-300">{step}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CareerCard;
