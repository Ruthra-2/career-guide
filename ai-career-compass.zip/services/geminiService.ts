
import { GoogleGenAI, Type } from "@google/genai";
import { CareerRecommendation, UserProfile } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const getCareerRecommendations = async (profile: UserProfile): Promise<CareerRecommendation[]> => {
  const prompt = `
    Based on the following student profile, suggest 3 diverse and well-suited career paths. For each career, provide a brief description, a clear reasoning for why it fits the profile, and a list of actionable next steps.

    Student Profile:
    - Skills: ${profile.skills}
    - Academic Performance / Favorite Subjects: ${profile.grades}
    - Hobbies & Interests: ${profile.interests}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: 'The title of the career path.'
              },
              description: {
                type: Type.STRING,
                description: 'A brief, engaging description of what the career entails.'
              },
              reasoning: {
                type: Type.STRING,
                description: 'A personalized explanation of why this career is a good match based on the student\'s profile.'
              },
              suggested_steps: {
                type: Type.ARRAY,
                items: {
                  type: Type.STRING
                },
                description: 'A list of 3-5 concrete, actionable next steps the student can take.'
              }
            },
            required: ['title', 'description', 'reasoning', 'suggested_steps']
          }
        },
      }
    });

    const jsonText = response.text.trim();
    const recommendations = JSON.parse(jsonText);
    return recommendations as CareerRecommendation[];
  } catch (error) {
    console.error("Error fetching career recommendations:", error);
    throw new Error("Failed to generate career recommendations from Gemini API.");
  }
};
